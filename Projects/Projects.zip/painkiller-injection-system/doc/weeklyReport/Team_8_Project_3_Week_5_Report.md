Participants:  胡馨月 罗金瞳 朱雯琳
Meeting Date:  2024.3.25
Project Leader: 朱雯琳
## Summary

Things finished since last meeting  

胡馨月（D）:  Nothing
罗金瞳（V）:  Nothing
朱雯琳（R）:  Write first draft of Software Requirement
## Questions prepared for the instructor team

Q1:  Should the injector set injection status?
Q2:  Could the database record the remaining amount of painkillers from sensor?
## Action Items (Plan for the next week):

胡馨月（D）:  Nothing
罗金瞳（V）:  Nothing
朱雯琳（R）:  Modify Software Requirement. Write Requirement_Group8_Painkiller(including System Objective, Domain Analysis, System Architecture, Use Cases and Software Requirement)