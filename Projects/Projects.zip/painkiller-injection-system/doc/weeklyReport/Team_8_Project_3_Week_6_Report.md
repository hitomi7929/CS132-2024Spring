Participants:  胡馨月 罗金瞳 朱雯琳
Meeting Date:  2024.4.1
Project Leader: 朱雯琳
## Summary

Things finished since last meeting  

胡馨月（D）:  Nothing
罗金瞳（V）:  Nothing
朱雯琳（R）:  Draw first draft of Software Requirement UML
## Questions prepared for the instructor team

Q1:  Should the class diagram involve Injection Processor?
Q2:  Could the system architecture diagram be drawn through specification?
## Action Items (Plan for the next week):

胡馨月（D）:  Draw specification UML, learning about QL
罗金瞳（V）:  Learning about QL
朱雯琳（R）:  Learning about QL