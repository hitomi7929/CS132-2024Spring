# CS132 Project3: PainkillerSystem Team 07 Week Report 6

Participants: Wenlin Zhu, Jintong Luo, Xinyue Hu

Meeting Date: 2024.05.16

Project Leader: Wenlin Zhu

## Summary

Things finished since last meeting

Wenlin Zhu: Revise the requirement for problems found in development.

Jintong Luo: Continue working on the initial design of the Painkiller system development.

Xinyue Hu: Test the prototype to find possible bugs.

We were having midterm examinations and waiting for API these weeks.

## Problems

* How to understand baseline?

## Action Items (Plan for the next week)

Xinyue Hu: Continue refining requirement if necessary.

Wenlin Zhu: Continue developing the prototype for the Elevator system backend and trying to fix the bugs.

Jintong Luo: Nothing, implement txtcases for her development.
