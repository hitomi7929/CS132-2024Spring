Participants:  胡馨月 罗金瞳 朱雯琳
Meeting Date:  2024.4.11
Project Leader: 朱雯琳
## Summary

Things finished since last meeting  

胡馨月（D）:  Learn QT.
罗金瞳（V）:  Learn QT.
朱雯琳（R）:  Prepare for the consulation and revise the requirement.
## Questions prepared for the instructor team

Q1:  Should the class diagram involve Injection Processor?
Q2:  Could the system architecture diagram be drawn through specification?
## Action Items (Plan for the next week):

胡馨月（D）:  Learn QT.
罗金瞳（V）:  Start to draw the UML for specification part and decide the architecture of the system. Learn QT as well.
朱雯琳（R）:  Learn QT.