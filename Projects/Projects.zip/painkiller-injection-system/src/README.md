# Team 7 Project 2: Painkiller System

* To run the painkiller system, please use `main.py`.
* In addition, we provide a test file `test.py` as an example for testing with txtcases.
* The standard for txtcases are as follows:

initialization: set simulation speed (real time 1s -> simulated time 2min)

case #1:\
set baseline 0.01ml/min -> set baseline as 0.01ml/min\
set bolus 0.30ml/shot -> set bolus as 0.30ml/shot\
baseline On -> turn on baseline\
(simulated time: about 30min later) Request Bolus -> patient requests for bolus (success)\
(simulated time: about 75min later) Request Bolus -> patient requests for bolus (fail)\
baseline Off -> turn off baseline\
set baseline 0.10ml/min -> set baseline as 0.10ml/min\
baseline On -> turn on baseline\
(simulated time: about 1-3min later) -> baseline reaches hour limit, stop\
(simulated time: 10min later) -> inject baseline every 10 min\
(after the day limit is reached) -> reach day limit, stop
