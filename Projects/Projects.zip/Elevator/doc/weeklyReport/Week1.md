# CS132 Project1: Elevator System Team 07 Week Report 1

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.03.25

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Give the requirement and update it.

Wenlin Zhu: Check the requirement and give some advice.

Jintong Luo: Check the requirement and give some advice.

## Problems

1. if a monitor system is needed?
2. if a database collecting data for training the system is need for a 3-floors building

## Questions prepared for the instructor team

1. is a database necessary? do simple varible store data for current state necessary?

## Action Items (Plan for the next week)

Xinyue Hu: Modify some details of requirement and start to draw UML.

Wenlin Zhu: Nothing, just start to complete the requirement of Project 3.

Jintong Luo: Nothing, just start to complete the requirement of Project 2.
