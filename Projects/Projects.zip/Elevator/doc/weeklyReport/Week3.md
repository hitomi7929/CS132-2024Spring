# CS132 Project1: Elevator System Team 07 Week Report 3

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.04.11

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Prepare for the consulation and revise the requirement.

Wenlin Zhu: Learn QT.

Jintong Luo: Learn QT.

## Problems

Nothing.

## Action Items (Plan for the next week)

Xinyue Hu: Learn QT

Wenlin Zhu: Start to draw the UML for specification part and decide the architecture of the system. Learn QT as well.

Jintong Luo: Learn QT.
