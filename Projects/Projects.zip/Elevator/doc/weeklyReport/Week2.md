# CS132 Project1: Elevator System Team 07 Week Report 2

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.04.01

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Give the UML in the requirement part

Wenlin Zhu: Nothing

Jintong Luo: Nothing

## Action Items (Plan for the next week)

Xinyue Hu: UML for project 1 continues; Start learning qt

Wenlin Zhu: Start learning qt and UML for project 3 continuing

Jintong Luo: Start learning qt and UML for project 2 continuing
