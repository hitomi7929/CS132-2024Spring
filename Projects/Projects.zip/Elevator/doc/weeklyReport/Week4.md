# CS132 Project1: Elevator System Team 07 Week Report 4

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.04.22

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Polish up Elevator system requirement documents.

Wenlin Zhu: Began working on the initial design of the Banking system development.

Jintong Luo: Nothing.

## Problems

Nothing.

## Action Items (Plan for the next week)

Xinyue Hu: Continue refining requirement if necessary.

Wenlin Zhu: Develop a prototype for Elevator system backend.

Jintong Luo: Nothing, do the development for her own part.
