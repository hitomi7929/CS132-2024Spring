# CS132 Project1: Elevator System Team 07 Week Report 8

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.06.03

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Revise the requirement for problems found in development.

Wenlin Zhu: Complete Elevator system with UI and a lot of bugs...

Jintong Luo: Test the prototype and find out some bugs.

## Problems

Nothing.

## Action Items (Plan for the next week)

Xinyue Hu: Continue refining requirement if necessary. Help Wenlin Zhu to debug.

Wenlin Zhu: Debug if possible.

Jintong Luo: Help Wenlin Zhu to debug. Consider the test cases based on requirement.
