# CS132 Project1: Elevator System Team 07 Week Report 10

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.06.21

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Requirement part was finished.

Wenlin Zhu: Nothing.

Jintong Luo: Finish unit tests and fix bugs found in validation.

## Problems

Nothing.

## Action Items (Plan for the next week)

Xinyue Hu: Requirement part was finished, nothing to do.

Wenlin Zhu: Nothing.

Jintong Luo: Finish validation.
