# CS132 Project1: Elevator System Team 07 Week Report 5

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.04.29

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Revise the requirement for problems found in development.

Wenlin Zhu: Continue working on the initial design of the Banking system development.

Jintong Luo: Test the prototype and find out some bugs.

## Problems

Nothing.

## Action Items (Plan for the next week)

Xinyue Hu: Continue refining requirement if necessary.

Wenlin Zhu: Continue developing the prototype for the Elevator system backend and trying to fix the bugs.

Jintong Luo: Nothing, do the development for her own part.
