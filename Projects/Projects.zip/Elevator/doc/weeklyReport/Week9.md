# CS132 Project1: Elevator System Team 07 Week Report 9

Participants: Xinyue Hu, Wenlin Zhu, Jintong Luo

Meeting Date: 2024.06.11

Project Leader: Xinyue Hu

## Summary

Things finished since last meeting

Xinyue Hu: Revise the requirement for problems found in development. Finish the development for Wenlin Zhu.

Wenlin Zhu: Nothing.

Jintong Luo: Test the prototype and find out some bugs. Finish the development for Wenlin Zhu.

## Problems

Nothing.

## Action Items (Plan for the next week)

Xinyue Hu: Continue refining requirement if necessary. Polish up development.

Wenlin Zhu: Nothing.

Jintong Luo: Polish up development. Start validation.
