import unittest
from PyQt5.QtTest import QTest
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *

import sys
sys.path.append("src")
from processor import SystemProcessor
from elevator import ElevatorState
from UIsettings import circle_button_style_on


'''
    TestElevatorProcessor_InternalUI_ExternalUI class tests the integration 
    between the elevator processor and its corresponding internal UI and external UI.
    
    Please run this file under the root path, i.e. Elevator.
'''
class TestElevatorProcessor_InternalUI_ExternalUI(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        """Initialize the test environment and set class-level variables."""
        cls.app = QApplication(sys.argv)

    def setUp(self):
        """Initialization of each test case."""
        self.system_processor = SystemProcessor()
        self.processor1 = self.system_processor.elevator_processors[0]
        self.processor2 = self.system_processor.elevator_processors[1]
        self.externalUIb = self.system_processor.externalUIs[0]
        self.externalUI1 = self.system_processor.externalUIs[1]
        self.externalUI2 = self.system_processor.externalUIs[2]
        self.externalUI3 = self.system_processor.externalUIs[3]
        self.internalUI1 = self.processor1.internal
        self.internalUI2 = self.processor2.internal
        self.externalUIb.show()
        self.externalUI1.show()
        self.externalUI2.show()
        self.externalUI3.show()
        self.internalUI1.show()
        self.internalUI2.show()

    def tearDown(self):
        """Cleanup after each test case."""
        self.externalUIb.close()
        self.externalUI1.close()
        self.externalUI2.close()
        self.externalUI3.close()
        self.internalUI1.close()
        self.internalUI2.close()

    @classmethod
    def tearDownClass(cls):
        """Cleanup work after all test cases are executed."""
        cls.app.quit()

    def test_elevator_integration(self):
        """Test the full integration scenario with detailed steps."""

        # T2.2.1: Press down button outside on floor 2.
        QTest.qWait(500)
        QTest.mouseClick(self.externalUI2.down_button, Qt.LeftButton)
        QTest.qWait(3000)

        # T2.2.1. Expected Output: Elevator 2 is called and the door will open when it arrives.
        self.assertEqual(self.processor2.elevator.current_floor, 2)
        self.assertTrue(self.processor2.checkOpen())
        self.assertEqual(self.internalUI2.open_close_state.text(), "<|>")
        self.assertEqual(self.internalUI2.open_close_state.styleSheet(), "color:green;")
        self.assertEqual(self.externalUI2.elevator_2_open_indicator.text(), "<|>")
        self.assertEqual(self.externalUI2.elevator_2_open_indicator.styleSheet(), "color:green;")

        # T2.2.2: When the door of elevator 2 is about to close, press open door button.
        QTest.qWait(10000)
        QTest.mouseClick(self.internalUI2.open_door_button, Qt.LeftButton)
        QTest.qWait(1000)

        # T2.2.2. Expected Output: The door of elevator 2 opens.
        self.assertTrue(self.processor2.checkOpen())
        self.assertEqual(self.internalUI2.open_close_state.text(), "<|>")
        self.assertEqual(self.internalUI2.open_close_state.styleSheet(), "color:green;")
        self.assertEqual(self.externalUI2.elevator_2_open_indicator.text(), "<|>")
        self.assertEqual(self.externalUI2.elevator_2_open_indicator.styleSheet(), "color:green;")

        # T2.2.3: Press floor -1 button in elevator 2, then press floor 3 button.
        QTest.qWait(1000)
        QTest.mouseClick(self.internalUI2.floor_button_b, Qt.LeftButton)
        QTest.qWait(1000)
        QTest.mouseClick(self.internalUI2.floor_button_3, Qt.LeftButton)
        QTest.qWait(1000)
        self.assertEqual(self.internalUI2.floor_button_b.styleSheet(), circle_button_style_on)
        self.assertEqual(self.internalUI2.floor_button_3.styleSheet(), circle_button_style_on)

        # T2.2.3. Expected Output: Elevator 2 moves to floor -1 at first.
        QTest.qWait(12000)
        self.assertEqual(self.internalUI2.floor_label.text(), "Floor: -1")
        self.assertEqual(self.externalUIb.elevator_2_floor_label.text(), "Floor -1")
        self.assertEqual(self.externalUI1.elevator_2_floor_label.text(), "Floor -1")
        self.assertEqual(self.externalUI2.elevator_2_floor_label.text(), "Floor -1")
        self.assertEqual(self.externalUI3.elevator_2_floor_label.text(), "Floor -1")

        # T2.2.4: When elevator 2 is on floor -1, press up button outside on floor 2.
        QTest.mouseClick(self.externalUI2.up_button, Qt.LeftButton)
        QTest.qWait(3000)

        # T2.2.4. Expected Output: Elevator 1 is called.
        self.assertEqual(self.internalUI1.floor_label.text(), "Floor: 2")
        self.assertEqual(self.externalUIb.elevator_1_floor_label.text(), "Floor 2")
        self.assertEqual(self.externalUI1.elevator_1_floor_label.text(), "Floor 2")
        self.assertEqual(self.externalUI2.elevator_1_floor_label.text(), "Floor 2")
        self.assertEqual(self.externalUI3.elevator_1_floor_label.text(), "Floor 2")

        # T2.2.5: Press close door button of elevator 1 when door is open.
        QTest.mouseClick(self.internalUI1.close_door_button, Qt.LeftButton)
        QTest.qWait(2000)

        # T2.2.5. Expected Output: Elevator 1 closes the door.
        self.assertEqual(self.processor1.elevator.current_state, ElevatorState.stopped_door_closed)
        self.assertEqual(self.internalUI1.open_close_state.text(), ">|<")
        self.assertEqual(self.internalUI1.open_close_state.styleSheet(), "color:black;")
        self.assertEqual(self.externalUI2.elevator_2_open_indicator.text(), ">|<")
        self.assertEqual(self.externalUI2.elevator_2_open_indicator.styleSheet(), "color:black;")

        # T2.2.3. Expected Output: Elevator 1 then moves to floor 3.
        QTest.qWait(10000)
        self.assertEqual(self.internalUI2.floor_label.text(), "Floor: 3")
        self.assertEqual(self.externalUIb.elevator_2_floor_label.text(), "Floor 3")
        self.assertEqual(self.externalUI1.elevator_2_floor_label.text(), "Floor 3")
        self.assertEqual(self.externalUI2.elevator_2_floor_label.text(), "Floor 3")
        self.assertEqual(self.externalUI3.elevator_2_floor_label.text(), "Floor 3")

        
if __name__ == "__main__":
    unittest.main()
